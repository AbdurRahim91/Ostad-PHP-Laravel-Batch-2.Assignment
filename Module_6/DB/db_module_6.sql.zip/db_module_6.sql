-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2023 at 06:03 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_module_6`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `creation_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `creation_date`) VALUES
(1, 'Electronics', '2023-11-03 19:17:20'),
(2, 'Appliances', '2023-11-03 19:17:20'),
(3, 'Clothing', '2023-11-03 19:17:39'),
(4, 'Home Decor', '2023-11-03 19:17:39'),
(5, 'Sports & Outdoors', '2023-11-03 19:18:21');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `name`, `email`, `location`, `created_date`) VALUES
(1, 'Md. Rabbil Hasan', 'rabbil@gmail.com', 'RUET, Rajshahi', '2023-11-03 19:06:05'),
(2, 'Md. Hasin Hyder', 'hasin@gmail.com', 'RUET, Rajshahi', '2023-11-03 19:06:05'),
(3, 'Prince Noman ', 'princenoman@gmail.com', 'Tangail', '2023-11-03 19:11:01'),
(4, 'Yousuf Alam', 'yousuf@gmail.com', 'Kishoreganj, Dhaka, Bangladesh', '2023-11-03 19:11:01'),
(5, 'Abdullah Al Musabbir', 'musabbir@gmail.com', 'KUET, Khulna', '2023-11-03 19:14:03'),
(6, 'Shourov Barua ', 'shourov@gmail.com', 'KUET, Khulna', '2023-11-03 19:14:03');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `total_amount` float NOT NULL,
  `order_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `total_amount`, `order_date`) VALUES
(1, 1, 50000, '2023-11-03 19:31:05'),
(2, 2, 50000, '2023-11-03 19:31:05'),
(3, 1, 25000, '2023-11-03 19:32:02'),
(4, 4, 20000, '2023-11-03 19:32:02'),
(5, 5, 25000, '2023-11-03 19:32:28'),
(6, 6, 450000, '2023-11-03 22:51:40');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` float NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`order_item_id`, `order_id`, `product_id`, `quantity`, `unit_price`, `created_date`) VALUES
(1, 1, 1, 1, 50000, '2023-11-03 19:37:40'),
(2, 2, 1, 1, 50000, '2023-11-03 19:37:40'),
(3, 3, 2, 1, 25000, '2023-11-03 19:39:01'),
(4, 4, 3, 1, 20000, '2023-11-03 19:39:01'),
(5, 5, 5, 10, 2500, '2023-11-03 19:40:35'),
(6, 6, 6, 10, 45000, '2023-11-03 22:52:14');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(250) NOT NULL,
  `price` float NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `description`, `price`, `category_id`, `created_date`) VALUES
(1, 'Laptop', 'High-performance laptop with SSD storage', 50000, 1, '2023-11-03 19:21:05'),
(2, 'Smartphone', 'Latest smartphone model with a large display', 25000, 1, '2023-11-03 19:21:05'),
(3, 'Tablet', '10-inch tablet with a powerful processor', 20000, 1, '2023-11-03 19:21:44'),
(4, 'Headphones', 'Noise-canceling wireless headphones', 1000, 1, '2023-11-03 19:23:00'),
(5, 'Smartwatch', 'Fitness tracker smartwatch with heart rate monitor', 2500, 1, '2023-11-03 19:23:00'),
(6, 'Refrigerator', 'A household appliance used for storing and preserving food at low temperatures.', 45000, 2, '2023-11-03 21:29:49'),
(7, 'Washing Machine', 'An appliance designed to clean and wash clothes automatically.', 25000, 2, '2023-11-03 21:29:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_item_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
